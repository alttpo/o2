This is an alpha version of usb2snes using a modified version of the sd2snes FW.

*** PLEASE BACKUP YOUR SD CARD BEFORE TRYING THIS ***
*** PLEASE BACKUP YOUR SD CARD BEFORE TRYING THIS ***
*** PLEASE BACKUP YOUR SD CARD BEFORE TRYING THIS ***

============================================================================
SETUP
============================================================================

[0] Install the correct sd2snes FW base version and verify it works
-------------------------------------------------------------------

See: https://sd2snes.de/blog/downloads

a) Update all *.im*, *.bi*, and the menu.bin.
b) Check the firmware version in the menu ([X]->System Information [A]->Firmware version).  It should read 1.10.3.

[1] SD2SNES 1.10.3-usb-v<NUMBER> USB Firmware Setup
---------------------------------------------------
a) Copy the contents of the sd2snes/ folder to your SD card's sd2snes/ folder.  You will overwrite the following files on your SD card:

SDSNES Classic:
- firmware.img
- fpga_base.bit

SD2SNES Pro
- firmware.im3
- fpga_base.bi3

It is safe (but not necessary) to copy all files in the sd2snes/ folder to either device.

b) Boot up the sd2snes with the SD card installed.
c) Check the firmware version ([X]->System Information [A]->Firmware version).  It should read 1.10.3-usb-v<NUMBER>.

If you have any problems you should try the unmodified FW available at: https://sd2snes.de/blog/downloads.  It doesn't have usb support, but testing it will help eliminate the usb changes as a cause of the problem.

If your custom menu no longer works you will need to update it to work with 1.10.3.  usb2snes does not change the menu.  Try updating it at: http://sd2snes.co.uk/

[2] Windows setup
-----------------
Plug in the sd2snes usb port to your windows machine
a) Install driver
   - If windows7, update your driver in Device Manager to the driver in the subdirectory: win7_driver/.
   - If windows8, it may work without installing a driver.  If it doesn't, you will need to disable signed driving checks and install the driver in win7_driver.  See: https://learn.sparkfun.com/tutorials/disabling-driver-signature-on-windows-8/disabling-signed-driver-enforcement-on-windows-8
   - If windows10, the correct driver should already be included with windows.
b) Check if the sd2snes is recognized.
   - In Device Manager check 'Ports (COM & LPT)' and look for your sd2snes.
     - In win7 it should say sd2snes.
     - In win10 it may have a generic name.
     - If there is a ! symbol over it there is a problem with the driver or the firmware has not been properly copied to the SD card (see step [1]).

You should hear the usb connection sound if it's properly connected and recognized.
- Make sure there are no unrecognized/errored devices in 'Universal Serial Bus controllers' section.
- If there are, make sure you install the driver if you're on win7.
- Your usb cable must support data transfers.  Cables only supporting power and not data won't work with usb2snes.  If in doubt, try another cable and another usb port on your computer.

WHEN UPDATING A PRIOR VERSION OF USB2SNES
-----------------------------------------
- Always make sure to copy the entire contents of sd2snes/ subdirectory appropriate for your device from the usb2snes zip to your SD card's sd2snes/ directory.  Often time changes in both the firmware (firmware.im*) and fpga code (fpga_*.bi*) are required for the latest usb2snes to work.
- If you copy any executables in the usb2snes/ directory to other locations make sure you also copy DLLs and other files from the same directory or it may not work.



********************************************************************************************
^^^^^^^ Everything above only needs to be done once for each new version of USB2SNES. ^^^^^^
********************************************************************************************
If you are using an application designed to connect to SD2SNES via USB (e.g. older versions of multitroid) you can probably stop here _unless_ that application also requires the tray app or something called websockets.




============================================================================
USB2SNES TRAY APP
============================================================================
[3] Try the usb2snes tray app.
The application opens as a tool tray app in the windows tool tray.  Look for a green circle with white lines inside it.
- Make sure your snes is on, the usb port is connected to your PC, and all the steps under the SETUP section are complete.
- Click on the green circle with the usb symbol in the tool tray to open a menu.
  - You should see a sd2snes section that opens up and displays COM#.  If the sd2snes section does not have an arrow and expand to show your com port, your sd2snes is not properly connected or the correct firmware files are not installed.  See the SETUP section.
- Highlight "Clients" to get a list of applications available.
  - The FileViewer allows access to the SD card and a few select menu options to control the sd2snes.
  - The InputViewer is a NintendoSpy-based button viewer that works for a small set of games.
  - The MemoryViewer is a debugging tool to view the current snes state (ROM, WRAM, OAM, CGRAM, etc).

In the FileViewer:
- upload lets you upload roms to the current directory.
- boot lets you start up a snes rom.  some roms (msu?) don't seem to work, yet.  (double click a ROM file in right window to boot it)
- patch lets you apply a IPS patch to a running game.
- other features are available: download, delete, rename, etc.  Right-click in the right window to see options.

The program should work both while in the sd2snes menu or in a game.

============================================================================
KNOWN BUGS
============================================================================
- Multiple apps can now be used at the same time, however, there are some cases where apps will stall and the whole usb2snes app may have to be killed/restarted along with the snes.

============================================================================
THANKS
============================================================================
Thanks to ikari for making the sd2snes.
Thanks to saturnu for the usb firmware source.  A lot of it has been rewritten, but the CDC/block transfer code still remains and other changes used the original code as reference.
Thanks to total for help with DKC save states and for the SM save state code which the IPS patch was based on.
Thanks to oste_hovel for help and developing multitroid.
Thanks to wildanaconda69 for help with testing and other feedback.
