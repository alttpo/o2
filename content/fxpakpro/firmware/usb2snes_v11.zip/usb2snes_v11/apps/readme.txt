To add an app:
- Create a directory with the same name you want displayed.
- Add an executable into that directory.  The tool tray app first looks for <directoryName>.exe and if that isn't found it uses the first executable in the directory listing.
